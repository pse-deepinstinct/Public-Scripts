1) Make sure script requirements are met by running:
   pip install -r requirements.txt
   
2) Call the script:
   python analyse_folder.py -s https:<your_server>:<port> -f <path to folder to scan> -o <name of your output file> [-r (optional for recursive folder scan)]