# DEEP INSTINCT MAKES NO WARRANTIES OR REPRESENTATIONS REGARDING DEEP INSTINCT’S PROGRAMMING SCRIPTS. 
# TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, DEEP INSTINCT DISCLAIMS ALL OTHER WARRANTIES, 
# REPRESENTATIONS AND CONDITIONS, WHETHER EXPRESS, STATUTORY, OR IMPLIED, INCLUDING, BUT NOT LIMITED 
# TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, 
# AND ANY WARRANTIES ARISING OUT OF COURSE OF DEALING OR USAGE OF TRADE. DEEP INSTINCT’S PROGRAMMING 
# SCRIPTS ARE PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTY OF ANY KIND, AND DEEP INSTINCT DISCLAIMS 
# ALL OTHER WARRANTIES, EXPRESS, IMPLIED OR STATUTORY, INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, 
# FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.



import os
import argparse
import pandas as pd
import hashlib
import requests
import base64

from tqdm.contrib.concurrent import process_map
from glob import glob

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from os import listdir


def scan_file_data(data, scan_url, encoded=False):
    if encoded:
        data = base64.b64encode(data)
        request_url = f'{scan_url}/scan/base64/v2'
    else:
        request_url = f'{scan_url}/scan/binary/v2'

    try:
        response = requests.post(request_url, data=data, timeout=20, verify=False)
    except Exception as e:
        return {'status': 0, 'details': {'error': str(e)}}

    if response.status_code == 200:
        return {'status': 1, 'details': response.json()}
    else:
        return {'status': 2, 'details': response.json()}


def submit_file_to_agentless(args):
    file_path, agentless_rest_address, b64 = args
    with open(file_path, 'rb') as f:
        data = f.read()
        f.close()
    result = scan_file_data(data, agentless_rest_address, b64)

    if result['status'] == 1:
        if 'scan_duration_in_microseconds' in result['details']:
            result['details']['scan_duration_in_milliseconds'] = int(
                result['details']['scan_duration_in_microseconds']) / 1000
    else:
        result['details']['verdict'] = 'Failed'
    result['details']['filename'] = file_path.split('/')[-1]
    result['details']['full_path'] = file_path
    result['details']['status'] = result['status']
    return result['details']


def calculate_md5_hash(record):
    with open(record['full_path'], "rb") as f:
        bytes = f.read()
        record['md5_hash'] = hashlib.md5(bytes).hexdigest()
    return record


def calculate_sha256_hash(record):
    with open(record['full_path'], "rb") as f:
        bytes = f.read()
        record['file_hash'] = hashlib.sha256(bytes).hexdigest()
    return record


def arg_definition():
    parser = argparse.ArgumentParser(description='Submit files to a DIPA instance',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                     epilog='')
    parser.add_argument('-s', '--server', dest='agentless_rest_address', help='Full address of Agentless instance (eg. https://localhost, https://localhost:5000, https://dipa-demo:5000)')
    parser.add_argument('-f', '--folder', dest='folder', help='Folder where files to scan are located')
    parser.add_argument('-o', '--output', dest='output_file', help='file to save scan results (defaults to output.csv)')
    parser.add_argument('-r', '--recurse', action='store_true', help='Recurse subfolders')
    parser.add_argument('-m', '--move', action='store_true', help='Move malicious files to a malicious folder')
    parser.add_argument('-d', '--delete', action='store_true', help='Delete malicious files to a malicious folder')
    parser.add_argument('-w', '--workers', dest='workers', help='number of concurrent workers')
    parser.add_argument('-md5', action='store_true', help='collect md5 hash of files')
    parser.add_argument('-sha256', action='store_true', help='Locally calculate sha256 hash of files')
    parser.add_argument('-b64', action='store_true', help='Use base64 when submitting files (default is binary)')
    return parser


if __name__ == '__main__':
    parser = arg_definition()
    arg_dict = {s: getattr(parser.parse_args(), s) for s in vars(parser.parse_args())}
    if not arg_dict['folder']:
        print('No folder or agentless address specified.')
        quit()
    if not arg_dict['agentless_rest_address']:
        print('There was no server specified, https://localhost will be used')
        arg_dict['agentless_rest_address'] = 'https://localhost'
    if arg_dict['recurse']:
        files = [[f, arg_dict['agentless_rest_address']] for f in glob(f'{arg_dict["folder"]}/**', recursive=True) if os.path.isfile(f)]
    else:
        files = [[f'{arg_dict["folder"]}/{s}', arg_dict['agentless_rest_address']] for s in listdir(arg_dict["folder"]) if os.path.isfile(f'{arg_dict["folder"]}/{s}')]
    if arg_dict['b64']:
        [s.append(True) for s in files]
    else:
        [s.append(False) for s in files]
    if arg_dict['move']:
        print('Malicious files will be moved')
    elif arg_dict['delete']:
        print('Malicious files will be deleted')
    else:
        print('Files will be scanned, but no action will be taken based on verdict')

    if arg_dict['workers']:
        workers = int(arg_dict['workers'])
    else:
        workers = 2

    chunk_size = workers * 2
    if chunk_size > len(files):
        chunk_size = len(files)

    results = process_map(submit_file_to_agentless, files, max_workers=workers, chunksize=chunk_size,
                          desc='Submitting files to Agentless')

    if arg_dict['md5']:
        results1 = process_map(calculate_md5_hash, results, max_workers=workers, chunksize=chunk_size,
                              desc='md5 hash requested, calculating')
        results = results1

    if arg_dict['sha256']:
        results1 = process_map(calculate_sha256_hash, results, max_workers=workers, chunksize=chunk_size,
                               desc='sha256 hash requested, calculating')
        results = results1

    malicious_files = [(s['filename'], s['full_path']) for s in results if s['verdict']=='Malicious']
    if arg_dict['move']:
        if not os.path.exists(f'{arg_dict["folder"]}/Malicious'):
            os.mkdir(f'{arg_dict["folder"]}/Malicious')
        [os.rename(s[1], f'{arg_dict["folder"]}/Malicious/{s[0]}') for s in malicious_files]
    elif arg_dict['delete']:
        [os.remove(s[1]) for s in malicious_files]

    stats = {}
    stats['Total Files'] = len(files)

    stats['Malicious'] = len([s for s in results if s['verdict'] == 'Malicious'])
    stats['Benign'] = len([s for s in results if s['verdict'] == 'Benign'])
    stats['Unsupported File Type'] = len([s for s in results if s['verdict'] == 'Unsupported File Type'])
    stats['Error'] = len([s for s in results if s['status'] != 1])
    stats['Unsupported File Size'] = len([s for s in results if s['verdict'] == 'Unsupported File Size'])
    stats['Timeout'] = len([s for s in results if s['verdict'] == 'Timeout'])
    stats['Classification Failed'] = len([s for s in results if s['verdict'] == 'Classification Failed'])
    stats['Total Scan Time(s)'] = sum([int(s["scan_duration_in_microseconds"]) for s in results if s.get("scan_duration_in_microseconds", 0)])/1000000
    stats['Total Size(MB)'] = sum([int(s["file_size_in_bytes"]) for s in results if s.get("file_size_in_bytes", 0)])/1000000
    if stats['Total Size(MB)'] > 0:
        stats['Throughput (MB/s)'] = "{:.2f}".format(stats['Total Size(MB)']/stats['Total Scan Time(s)'])
    else:
        stats['Throughput (MB/s)'] = 0

    key_length = max([len(s) for s in stats.keys()])
    print(key_length)
    for n in stats:
        print('{0:<27}'.format(n), stats[n])

    if not arg_dict['output_file']:
        out_file = 'output.csv'
    else:
        out_file = arg_dict['output_file']

    df = pd.DataFrame.from_dict(results)
    df.to_csv(out_file, index=False)

    print(f'Detailed results available in {out_file}.')