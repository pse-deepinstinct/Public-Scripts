import requests
import base64

def scan_file_data(data, scan_url, encoded=False):
    if encoded:
        data = base64.b64encode(data)
        request_url = f'{scan_url}/scan/base64'
    else:
        request_url = f'{scan_url}/scan/binary'

    try:
        response = requests.post(request_url, data=data, timeout=20, verify=False)
    except Exception as e:
        return {'status': 0, 'details': {'error': str(e)}}

    if response.status_code == 200:
        return {'status': 1, 'details': response.json()}
    else:
        return {'status': 2, 'details': response.json()}



def scan_file(file_name, scan_url, encoded=False):
    with open(file_name, 'rb') as f:
        data = f.read()
        f.close()
    return scan_file_data(data, scan_url, encoded)